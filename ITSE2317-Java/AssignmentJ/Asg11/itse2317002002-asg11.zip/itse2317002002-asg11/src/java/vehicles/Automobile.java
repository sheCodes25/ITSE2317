package vehicles;

public class Automobile
{
  private String autoMake;
  private String autoModel;
  private String autoColor;
  private String autoReg;
  
  public Automobile(String make, String model, String color, String reg)
  {
    setAutoMake(make);
    setAutoModel(model);
    setAutoColor(color);
    setAutoReg(reg);
  }
  
  public void setAutoMake(String make)
  {
    if (make.length() > 0) {
      this.autoMake = make;
    } else {
      this.autoMake = "No Value Entered!";
    }
  }
  
  public void setAutoModel(String model)
  {
    if (model.length() > 0) {
      this.autoModel = model;
    } else {
      this.autoModel = "No Value Entered!";
    }
  }
  
  public void setAutoColor(String color)
  {
    if (color.length() > 0) {
      this.autoColor = color;
    } else {
      this.autoColor = "No Value Entered!";
    }
  }
  
  public void setAutoReg(String reg)
  {
    if (reg.length() > 0) {
      this.autoReg = reg;
    } else {
      this.autoReg = "No Value Entered!";
    }
  }
  
  public String getAutoMake()
  {
    return this.autoMake;
  }
  
  public String getAutoModel()
  {
    return this.autoModel;
  }
  
  public String getAutoColor()
  {
    return this.autoColor;
  }
  
  public String getAutoReg()
  {
    return this.autoReg;
  }
}
