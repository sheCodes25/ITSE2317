package vehicles;

public class Aircraft
{
  private String airMake;
  private String airModel;
  private String airColor;
  private String airReg;
  
  public Aircraft(String make, String model, String color, String reg)
  {
    setAirMake(make);
    setAirModel(model);
    setAirColor(color);
    setAirReg(reg);
  }
  
  public void setAirMake(String make)
  {
    if (make.length() > 0) {
      this.airMake = make;
    } else {
      this.airMake = "No Value Entered!";
    }
  }
  
  public void setAirModel(String model)
  {
    if (model.length() > 0) {
      this.airModel = model;
    } else {
      this.airModel = "No Value Entered!";
    }
  }
  
  public void setAirColor(String color)
  {
    if (color.length() > 0) {
      this.airColor = color;
    } else {
      this.airColor = "No Value Entered!";
    }
  }
  
  public void setAirReg(String reg)
  {
    if (reg.length() > 0) {
      this.airReg = reg;
    } else {
      this.airReg = "No Value Entered!";
    }
  }
  
  public String getAirMake()
  {
    return this.airMake;
  }
  
  public String getAirModel()
  {
    return this.airModel;
  }
  
  public String getAirColor()
  {
    return this.airColor;
  }
  
  public String getAirReg()
  {
    return this.airReg;
  }
}
