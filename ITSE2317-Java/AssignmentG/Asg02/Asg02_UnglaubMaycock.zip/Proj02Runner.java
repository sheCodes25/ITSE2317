
/* asg02 ITSE 2317 Summer 2018
 * Author: Petra Unglaub-Maycock 
 * Teacher: Professor Baldwin*/

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

class Proj02Runner
{
  private boolean forwardSort = true;
  
  Proj02Runner()
  {
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();
  }
  
  Collection<String> getCollection(String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList(Arrays.asList(paramArrayOfString));
    if (this.forwardSort)
    {
      Collections.sort(localArrayList, String.CASE_INSENSITIVE_ORDER);
    }
    else
    {
      Collections.sort(localArrayList, String.CASE_INSENSITIVE_ORDER);
      
      Collections.reverse(localArrayList);
    }
    return localArrayList;
  }
}
