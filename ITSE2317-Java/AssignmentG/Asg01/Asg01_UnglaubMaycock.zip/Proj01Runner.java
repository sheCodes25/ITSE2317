/* asg01 ITSE 2317 Summer 2018
 * Author: Petra Unglaub-Maycock 
 * Teacher: Professor Baldwin*/

import java.util.*;

class Proj01Runner 
{
  private boolean forwardSort = false;
  
  Proj01Runner() 
  {
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();  
  }
  
  Collection<String> getCollection(String[] paramArrayOfString)
  { 
    ArrayList localArrayList = new ArrayList(Arrays.asList(paramArrayOfString));
    if (this.forwardSort) {
      Collections.sort(localArrayList);
    } else {
      Collections.sort(localArrayList, 
        Collections.reverseOrder());
    }
    return localArrayList;
  }
}