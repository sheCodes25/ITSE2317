import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.TreeSet;


class Proj04Runner
{
  private boolean forwardSort = false;
  
  Proj04Runner()
  {
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();
  }
  
  Collection<String> getCollection(String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList(Arrays.asList(paramArrayOfString));
    
    TreeSet localTreeSet1 = null;
    if (this.forwardSort)
    {
      localTreeSet1 = new TreeSet(String.CASE_INSENSITIVE_ORDER);
      
      localTreeSet1.addAll(localArrayList);
    }
    else
    {
      TreeSet localTreeSet2 = new TreeSet(String.CASE_INSENSITIVE_ORDER);
      
      localTreeSet2.addAll(localArrayList);
      
      localTreeSet1 = new TreeSet(Collections.reverseOrder());
      
      localTreeSet1.addAll(localTreeSet2);
    }
    return localTreeSet1;
  }
}
