/* asg 03 for ITSE 2317
 * Author: Petra Unglaub-Maycock
 * Teacher: Prof Baldwin
 */

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.TreeSet;

class Proj03Runner
{
  private boolean forwardSort = false;
  
  Proj03Runner() // constructor 
  {
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println(); // end Proj03Runner constructor
  }
 
  Collection<String> getCollection(String[] paramArrayOfString)
  { // instantiates and returns TreeSet<String> myTreeSet
    ArrayList localArrayList = new ArrayList(Arrays.asList(paramArrayOfString));
    
    TreeSet localTreeSet = null;
    if (this.forwardSort)
    {
      localTreeSet = new TreeSet(localArrayList);
    }
    else
    {
      localTreeSet = new TreeSet(Collections.reverseOrder());
      
      localTreeSet.addAll(localArrayList);
    }
    return localTreeSet;
  } // end getCollection method
} // end Poj01Runner class
