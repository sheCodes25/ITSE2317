/*File Proj05.java Copyright 2002 R.G.Baldwin
**********************************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Proj05 {
  public static void main(String[] args){
    new Proj05Runner();
  }//end main
}//end class Proj05
//=======================================================//