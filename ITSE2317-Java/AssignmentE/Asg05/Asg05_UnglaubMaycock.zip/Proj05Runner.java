import java.awt.*;
import java.awt.event.*;
import java.io.PrintStream;
import javax.swing.*;

class Proj05Runner
{
  private boolean redOutput = false;
  
  public Proj05Runner()
  {
    JFrame localJFrame = new JFrame();
    localJFrame.setSize(200, 200);
    localJFrame.setTitle("Petra Unglaub-Maycock");
    JButton localJButton = new JButton("Quit");
    localJFrame.getContentPane().add(localJButton, "North");
    Proj05Runner.DisplaySpace localDisplaySpace = new Proj05Runner.DisplaySpace();
    localJFrame.getContentPane().add(localDisplaySpace, "Center");
    
    System.out.println("Proj05");
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();
    if (this.redOutput) {
      localDisplaySpace.setForeground(Color.RED);
    } else {
      localDisplaySpace.setForeground(Color.BLACK);
    }
    localJFrame.setDefaultCloseOperation(0);
    
    localJFrame.setVisible(true);
    
    localJButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        System.exit(0);
      }
    });
    localDisplaySpace.addMouseListener(new Proj05Runner.MProc1(localDisplaySpace));
  }
  
  private class DisplaySpace extends JPanel
  {
    int clickX;
    int clickY;
    
    private DisplaySpace() {}
    
    public void paintComponent(Graphics paramGraphics)
    {
      super.paintComponent(paramGraphics);
      if (Proj05Runner.this.redOutput) {
        paramGraphics.drawString("X=" + this.clickX + ", Y=" + this.clickY, this.clickX, this.clickY);
      } else {
        paramGraphics.drawString("" + this.clickX + ", " + this.clickY, this.clickX, this.clickY);
      }
    }
  }
  
  private class MProc1 implements MouseListener
  {
    Proj05Runner.DisplaySpace refToWin;
    
    MProc1(Proj05Runner.DisplaySpace paramDisplaySpace)
    {
      this.refToWin = paramDisplaySpace;
    }
    
    public void mouseClicked(MouseEvent paramMouseEvent) {}
    
    public void mouseReleased(MouseEvent paramMouseEvent) {}
    
    public void mouseEntered(MouseEvent paramMouseEvent) {}
    
    public void mouseExited(MouseEvent paramMouseEvent) {}
    
    public void mousePressed(MouseEvent paramMouseEvent)
    {
      this.refToWin.clickX = paramMouseEvent.getX();
      this.refToWin.clickY = paramMouseEvent.getY();
      this.refToWin.repaint();
    }
  }
}
