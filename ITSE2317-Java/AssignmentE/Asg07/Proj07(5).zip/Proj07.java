/*File Proj07.java Copyright 2002 R.G.Baldwin
**********************************************************/
import javax.swing.JFrame;
public class Proj07{
  public static void main(String[] args){
    JFrame aFrame = new Proj07Runner();
  }//end main
}//end class Proj07