import java.awt.BorderLayout;
import java.awt.Container;
import java.io.PrintStream;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class Proj08Runner
  extends JFrame
{
  private JPanel mainPanel = new JPanel();
  private JPanel titlePanel = new JPanel();
  private JSlider slider = new JSlider();
  private JLabel jLabel = new JLabel("50", 0);
  private boolean jLabelAtTop = true;
  
  public Proj08Runner()
  {
    System.out.println("Proj08");
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();
    
    setDefaultCloseOperation(3);
    
    this.slider.setMajorTickSpacing(10);
    this.slider.setMinorTickSpacing(2);
    this.slider.setPaintTicks(true);
    this.slider.setPaintLabels(true);
    
    this.mainPanel.setLayout(new BorderLayout());
    if (this.jLabelAtTop) {
      this.titlePanel.add(this.jLabel);
    } else {
      this.mainPanel.add(this.jLabel, "South");
    }
    this.mainPanel.add(this.titlePanel, "North");
    this.mainPanel.add(this.slider, "Center");
    
    getContentPane().add(this.mainPanel);
    pack();
    
    setTitle("Petra Unglaub-Maycock");
    pack();
    setVisible(true);
    
    this.slider.addChangeListener(new ChangeListener()
    {
      public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
      {
        Proj08Runner.this.jLabel.setText("" + Proj08Runner.this.slider.getValue());
      }
    });
  }
}
