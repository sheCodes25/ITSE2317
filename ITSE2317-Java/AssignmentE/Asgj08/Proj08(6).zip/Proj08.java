//34567890123456789012345678901234567890123456789012345678
/*File Proj08 Copyright 2008 R.G.Baldwin
*********************************************************/
public class Proj08{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    new Proj08Runner();
  }//end main method
}//end class Proj08
//End program specifications.