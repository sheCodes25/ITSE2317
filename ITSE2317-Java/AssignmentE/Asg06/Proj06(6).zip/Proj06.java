/*File Proj06.java Copyright 2002 R.G.Baldwin
**********************************************************/
import java.awt.Frame;

public class Proj06 {
  public static void main(String[] args){
    Frame aFrame = new Proj06Runner();
  }//end main
}//end class Proj06