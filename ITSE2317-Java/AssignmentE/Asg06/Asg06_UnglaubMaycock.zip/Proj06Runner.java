import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.PrintStream;

class Proj06Runner
  extends Frame
{
  private int xCoor;
  private int yCoor;
  private Proj06Runner thisFrame;
  private Panel myPanel = new Proj06Runner.MyPanel();
  private boolean addPanel = false;
  
  public Proj06Runner()
  {
    setTitle("Petra Unglaub-Maycock");
    setSize(300, 200);
    
    add(new Button("This Button does nothing"), "North");
    
    add(new TextField("This TextField does nothing"), "South");
    
    add(new Button("Button"), "West");
    if (this.addPanel) {
      add(this.myPanel);
    }
    setVisible(true);
    this.thisFrame = this;
    
    addWindowListener(new Proj06Runner.WindowCloser());
    if (this.addPanel) {
      this.myPanel.addMouseMotionListener(new Proj06Runner.MouseHandler());
    } else {
      addMouseMotionListener(new Proj06Runner.MouseHandler());
    }
    System.out.println("Proj06");
    System.out.println("I certify that this program is my own work");
    
    System.out.println("and is not the work of others. I agree not");
    
    System.out.println("to share my solution with others.");
    System.out.println("Petra Unglaub-Maycock.");
    System.out.println();
  }
  
  public void paint(Graphics paramGraphics)
  {
    paramGraphics.drawString("" + this.xCoor + ", " + this.yCoor, this.xCoor, this.yCoor);
  }
  
  private class MyPanel
    extends Panel
  {
    private MyPanel() {}
    
    public void paint(Graphics paramGraphics)
    {
      paramGraphics.drawString("" + Proj06Runner.this.xCoor + ", " + Proj06Runner.this.yCoor, Proj06Runner.this.xCoor, Proj06Runner.this.yCoor);
    }
  }
  
  private class MouseHandler
    extends MouseMotionAdapter
  {
    private MouseHandler() {}
    
    public void mouseDragged(MouseEvent paramMouseEvent)
    {
      if (Proj06Runner.this.addPanel) {
        Proj06Runner.this.myPanel.setForeground(Color.RED);
      } else {
        Proj06Runner.this.thisFrame.setForeground(Color.BLACK);
      }
      Proj06Runner.this.xCoor = paramMouseEvent.getX();
      Proj06Runner.this.yCoor = paramMouseEvent.getY();
      if (Proj06Runner.this.addPanel) {
        Proj06Runner.this.myPanel.repaint();
      } else {
        Proj06Runner.this.thisFrame.repaint();
      }
    }
    
    public void mouseMoved(MouseEvent paramMouseEvent)
    {
      if (Proj06Runner.this.addPanel) {
        Proj06Runner.this.myPanel.setForeground(Color.BLACK);
      } else {
        Proj06Runner.this.thisFrame.setForeground(Color.RED);
      }
      Proj06Runner.this.xCoor = paramMouseEvent.getX();
      Proj06Runner.this.yCoor = paramMouseEvent.getY();
      if (Proj06Runner.this.addPanel) {
        Proj06Runner.this.myPanel.repaint();
      } else {
        Proj06Runner.this.thisFrame.repaint();
      }
    }
  }
  
  private class WindowCloser
    extends WindowAdapter
  {
    private WindowCloser() {}
    
    public void windowClosing(WindowEvent paramWindowEvent)
    {
      System.exit(0);
    }
  }
}
